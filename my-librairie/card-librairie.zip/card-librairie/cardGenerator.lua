local okBg, cardBackGround = pcall(love.graphics.newImage, 'img/card/CardTheme/card.jpg'); if not okBg then cardBackGround = nil end;
local okDeco, cardDecoration = pcall(love.graphics.newImage, 'img/card/CardTheme/decoration.png'); if not okDeco then cardDecoration = nil end;
local okPow, CardPastille = pcall(love.graphics.newImage, 'img/card/CardTheme/power.png'); if not okPow then CardPastille = nil end;
local Generator = {}

--[[

Fonction : generateCanvasCard

Rôle : Fonction « Generate canvas card » liée à la logique du jeu.

Paramètres :

  - p_cart : paramètre détecté automatiquement.

Retour : aucune valeur (nil).

]]

local function generateCanvasCard(p_cart)
    -- create canvas
    local graphicsCard = love.graphics.newCanvas(337, 462);

    love.graphics.clear();

    -- direct drawing operations to the canvas
    love.graphics.setCanvas(graphicsCard);
    love.graphics.rectangle('fill', 0, 0, 338, 462);
    if p_cart.card then
        love.graphics.draw(p_cart.card, 0, 0)
    else
        love.graphics.setColor(1, 1, 1, 1); love.graphics.rectangle('fill', 0, 0, 338, 462, 12, 12);
    end;

    if p_cart.ilustration then
        love.graphics.draw(p_cart.ilustration, 57, 50);
    else
        love.graphics.setColor(0.12, 0.12, 0.14, 0.95);
        love.graphics.rectangle('fill', 57, 50, 224, 300, 12, 12);
        love.graphics.setColor(1, 1, 1, 0.85);
        love.graphics.rectangle('line', 57, 50, 224, 300, 12, 12);
        love.graphics.setColor(1, 1, 1, 1);
        if p_cart.name then love.graphics.printf(p_cart.name, 57, 50 + 128, 224, 'center') end
    end
    if p_cart.decoration then love.graphics.draw(p_cart.decoration, 31, 17) end;

    love.graphics.draw(p_cart.powerPastille, 15, 22);
    love.graphics.setNewFont(30);
    love.graphics.print(p_cart.PowerBlowCard, 35, 35);
    love.graphics.setNewFont(20);
    love.graphics.print(p_cart.description, 66, 271);
    love.graphics.setNewFont(25);
    love.graphics.print(p_cart.name, 100, 20);

    -- re-enable drawing to the main screen
    love.graphics.setCanvas();

    return graphicsCard;
end

--[[

Fonction : Generator.newCard

Rôle : Fonction « New card » liée à la logique du jeu.

Paramètres :

  - p_cardName : paramètre détecté automatiquement.

  - p_ilustration : paramètre détecté automatiquement.

  - p_description : paramètre détecté automatiquement.

  - p_power : paramètre détecté automatiquement.

  - p_effect : paramètre détecté automatiquement.

  - p_cont : paramètre détecté automatiquement.

  - actorName : paramètre détecté automatiquement.

Retour : aucune valeur (nil).

]]

function Generator.newCard(p_cardName, p_ilustration, p_description, p_power, p_effect, p_cont, actorName)
    if (actorName == nil) then
        actorName = 'Hero';
    end

    for i = 1, p_cont do
        local cart = {};
        cart.vector2 = {
            x = screen.gameReso.width - 337 / 2,
            y = screen.gameReso.height - (462 / 2)
        };
        cart.scale = {
            x = 0.5,
            y = 0.5
        };
        cart.name = p_cardName;
        cart.card = cardBackGround;
        cart.decoration = cardDecoration;
        local okIlus, _img = pcall(love.graphics.newImage, p_ilustration); cart.ilustration = okIlus and _img or nil;
        cart.powerPastille = CardPastille;
        cart.description = p_description;
        cart.PowerBlowCard = p_power;
        cart.oldVector2 = {
            x = 60,
            y = 900
        };
        cart.effect = p_effect;

        local Width, Height = cart.card:getDimensions();
        cart.height = Height;
        cart.width = Width;
        -- generate canvas card
        cart.canvas = generateCanvasCard(cart);

        -- table.insert(card.objet, cart);
        if (actorName == 'Hero') then
            table.insert(card.deck, cart);
            return card.deck;
        else
            table.insert(card.deckAi, cart);
            return card.deckAi;
        end
    end
end

return Generator
