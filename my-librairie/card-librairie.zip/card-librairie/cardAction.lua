local heal          = require("my-librairie/card-librairie/cardEffect/heal")
local attack        = require("my-librairie/card-librairie/cardEffect/attack")
local epine         = require("my-librairie/card-librairie/cardEffect/giveEpine")
local shield        = require("my-librairie/card-librairie/cardEffect/giveSheld")

local effects       = require("ressources/effect")

local action        = {}
local listeCarte    = {}
local ongoingAction = false

-- utils
--[[
Fonction : num
Rôle : Fonction « Num » liée à la logique du jeu.
Paramètres :
  - v : paramètre détecté automatiquement.
Retour : valeur calculée.
]]
local function num(v) return tonumber(v) or 0 end


--[[


Fonction : action.Apllique


Rôle : Fonction « Apllique » liée à la logique du jeu.


Paramètres :


  - p_card : paramètre détecté automatiquement.


  - p_newValue : paramètre détecté automatiquement.


Retour : valeur calculée.


]]
function action.Apllique(p_card, p_newValue)
    if not p_card then return false end

    if p_newValue == nil then
        -- support PowerBlow / PowerBlowCard / cost
        p_newValue = p_card.PowerBlowCard or p_card.PowerBlow or p_card.cost or 0
    end

    if Hero.actor.state.power < p_newValue then
        return false
    end

    Hero.actor.state.power = Hero.actor.state.power - p_newValue
    table.insert(listeCarte, p_card)
    return true
end

--[[

Fonction : action.update

Rôle : Met à jour la logique à chaque frame.

Paramètres :

  - (aucun)

Retour : aucune valeur (nil).

]]
function action.update()
    if ongoingAction == false and listeCarte[1] ~= nil and (not effects.active or #effects.active == 0) then
        if Hero.actor.animation.isPlay == false and Enemies.curentEnemy.animation.isPlay == false then
            ongoingAction = true
            action.play(listeCarte[1])
        end
    end
end

--[[

Fonction : prepareNextAction

Rôle : Fonction « Prepare next action » liée à la logique du jeu.

Paramètres :

  - p_card : paramètre détecté automatiquement.

Retour : aucune valeur (nil).

]]
local function prepareNextAction(p_card)
    -- retire la carte de la file
    table.remove(listeCarte, 1)

    -- renvoie la carte hors de l'écran (anim de retour)
    p_card.vector2.x = screen.gameReso.width
    p_card.vector2.y = screen.gameReso.height - p_card.height / 2

    -- au cimetière
    table.insert(card.Graveyard, p_card)

    -- repositionne la main
    card.positioneHand()
    ongoingAction = false
end

--[[

Fonction : action.play

Rôle : Fonction « Play » liée à la logique du jeu.

Paramètres :

  - p_card : paramètre détecté automatiquement.

Retour : aucune valeur (nil).

]]
function action.play(p_card)
    -- normalise la structure des effets (support Effect/effect)
    local eff = p_card.effect;
    local heroEff = p_card.effect.hero;
    local enemyEff = p_card.effect.enemy;


    -- ======================
    --         HEAL
    -- ======================
    if num(heroEff.heal) > 0 then heal.give(p_card, Hero.actor, num(heroEff.heal)) end
    if num(enemyEff.heal) > 0 then heal.give(p_card, Enemies.curentEnemy, num(enemyEff.heal)) end

    -- ======================
    --        SHIELD
    -- ======================
    if num(heroEff.shield) > 0 then shield.applique(p_card, Hero.actor, num(heroEff.shield)) end
    if num(enemyEff.shield) > 0 then shield.applique(p_card, Enemies.curentEnemy, num(enemyEff.shield)) end

    -- ======================
    --        ATTACK
    -- ======================
    -- dégât vers l'ennemi (côté Enemy = valeur posée sur l’ennemi dans tes defs)
    if num(enemyEff.attack) > 0 then
        attack.applique(p_card, Hero.actor, Enemies.curentEnemy, num(enemyEff.attack))
    end
    -- dégât vers le héros (si une carte ennemie utilisait Hero.attack)
    if num(heroEff.attack) > 0 then
        attack.applique(p_card, Enemies.curentEnemy, Hero.actor, num(heroEff.attack))
    end

    -- ======================
    --         EPINE
    -- ======================
    if num(enemyEff.Epine) > 0 then epine.applique(p_card, Enemies.curentEnemy, num(enemyEff.Epine)) end
    if num(heroEff.Epine) > 0 then epine.applique(p_card, Hero.actor, num(heroEff.Epine)) end

    -- ======================
    --  CHANCE ENEMY PASS TOUR
    -- ======================
    if num(enemyEff.chancePassedTour) > 0 then
        Enemies.curentEnemy.state.chancePassTour =
            (Enemies.curentEnemy.state.chancePassTour or 0) + num(enemyEff.chancePassedTour)
    end

    -- ======================
    --   ACTION SCRIPTÉE
    -- ======================
    if type(eff.action) == "function" then
        eff.action(Hero)
    end

    prepareNextAction(p_card)
end

return action
