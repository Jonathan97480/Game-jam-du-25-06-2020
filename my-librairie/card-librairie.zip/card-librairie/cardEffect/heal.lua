local effect = require("ressources/effect")
local heal = {}


-- Soigne p_actor et renvoie la quantité réellement soignée (0 si rien)
--[[
Fonction : heal.give
Rôle : Fonction « Give » liée à la logique du jeu.
Paramètres :
  - p_card : paramètre détecté automatiquement.
  - p_actor : paramètre détecté automatiquement.
  - heal_value : paramètre détecté automatiquement.
Retour : valeur calculée.
]]
function heal.give(p_card, p_actor, heal_value)
    if not p_actor or not p_actor.state then return 0 end

    local maxLife = tonumber(p_actor.state.maxLife) or 0
    local life    = tonumber(p_actor.state.life) or 0
    local want    = tonumber(heal_value) or 0
    if want <= 0 then return 0 end

    local missing = maxLife - life
    if missing <= 0 then return 0 end -- déjà full vie

    local amount = math.min(want, missing)

    -- applique le soin
    p_actor.state.life = life + amount

    -- animation (optionnelle)
    effect.play('heal', p_actor.vector2.x, p_actor.vector2.y, {
        speed = 0.2,
        sx    = 1.2,
        sy    = 1.2
    });


    return amount
end

return heal
