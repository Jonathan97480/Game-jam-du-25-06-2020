local effect = require("ressources/effect")
local attack = {}

--[[

Fonction : attack.applique

Rôle : Fonction « Applique » liée à la logique du jeu.

Paramètres :

  - p_card : paramètre détecté automatiquement.

  - p_actorA : paramètre détecté automatiquement.

  - p_actorB : paramètre détecté automatiquement.

  - p_value : paramètre détecté automatiquement.

Retour : aucune valeur (nil).

]]

attack.applique = function(p_card, p_actorA, p_actorB, p_value)
    actorManager.applyEffect(p_actorB, 'damage', -p_value, { source = p_actorA });

    effect.play('attack', p_actorB.vector2.x, p_actorB.vector2.y);
end



return attack;
