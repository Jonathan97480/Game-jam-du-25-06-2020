local effect = require("ressources/effect")
local giveSheld = {}

--[[

Fonction : giveSheld.applique

Rôle : Fonction « Applique » liée à la logique du jeu.

Paramètres :

  - p_card : paramètre détecté automatiquement.

  - p_actor : paramètre détecté automatiquement.

  - p_value : paramètre détecté automatiquement.

Retour : aucune valeur (nil).

]]

giveSheld.applique = function(p_card, p_actor, p_value)
  --[[ p_actor.state.shield = p_actor.state.shield + p_value; ]]
  actorManager.applyEffect(p_actor, 'shield', p_value)
  effect.play('shield', p_actor.vector2.x, p_actor.vector2.y);
end


return giveSheld;
