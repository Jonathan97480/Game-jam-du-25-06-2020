-- REQUIRE
local generateCard = require("my-librairie/card-librairie/cardGenerator");
local cardsInHand = require("my-librairie/card-librairie/repositioningCardsInHand");
local cardOver = require("my-librairie/card-librairie/cardOver");
local func = require("my-librairie/card-librairie/cardFunction");

local cards = {};
cards.func = func;
cards.hand = {};
--[[ LE DECK ]]
cards.deck = {};
cards.deckAi = {};
--[[ LE SIMETIERE ]]
cards.Graveyard = {};
--[[ GENERATION CARD ]]
--[[
Fonction : cards.create
Rôle : Crée et prépare une instance ou ressource.
Paramètres :
  - p_cardName : paramètre détecté automatiquement.
  - p_ilustration : paramètre détecté automatiquement.
  - p_description : paramètre détecté automatiquement.
  - p_power : paramètre détecté automatiquement.
  - p_effect : paramètre détecté automatiquement.
  - p_cont : paramètre détecté automatiquement.
Retour : valeur calculée.
]]
cards.create = function(p_cardName, p_ilustration, p_description, p_power, p_effect, p_cont)
    return generateCard.newCard(p_cardName, p_ilustration, p_description, p_power, p_effect, p_cont);
end

-- HOVER MOUSE DETECTION
--[[
Fonction : cards.hover
Rôle : Fonction « Hover » liée à la logique du jeu.
Paramètres :
  - dt : paramètre détecté automatiquement.
Retour : aucune valeur (nil).
]]
function cards.hover(dt)
    cardOver.hover(dt);
end

--[[

Fonction : cards.clearHand

Rôle : Fonction « Clear hand » liée à la logique du jeu.

Paramètres :

  - (aucun)

Retour : aucune valeur (nil).

]]

cards.clearHand = function()
    for i = 1, #cards.hand do
        local value = cards.hand[i];
        table.insert(cards.Graveyard, value);
    end

    cards.hand = {};
end

-- Return canvas

--[[

Fonction : cards.tirage

Rôle : Fonction « Tirage » liée à la logique du jeu.

Paramètres :

  - p_numbercardHand : paramètre détecté automatiquement.

Retour : aucune valeur (nil).

]]

function cards.tirage(p_numbercardHand)
    cardsInHand.tirage(p_numbercardHand);
end

--[[ GENERATION CARD ]]
--[[
Fonction : cards.positioneHand
Rôle : Fonction « Positione hand » liée à la logique du jeu.
Paramètres :
  - (aucun)
Retour : aucune valeur (nil).
]]
function cards.positioneHand()
    cardsInHand.repositioningCardsInHand();
end

--[[ GET CARDS BY NAME
    Récupère les cartes par leur nom dans les zones spécifiées.

    @param name Le nom de la carte à rechercher.
    @param scopes Les zones à rechercher (main, deck, cimetière) recherche dans les trois tables si non spécifié.
    @return Une table contenant les cartes trouvées.
]]
--[[
Fonction : cards.getCardsByName
Rôle : Fonction « Get cards by name » liée à la logique du jeu.
Paramètres :
  - name : paramètre détecté automatiquement.
  - scopes : paramètre détecté automatiquement.
Retour : aucune valeur (nil).
]]
function cards.getCardsByName(name, scopes)
    local out = {}
    local c, zone, idx = nil, nil, nil
    scopes = scopes or { "hand", "deck", "Graveyard" }
    local target = string.lower(name or "")
    for _, z in ipairs(scopes) do
        local list = cards[z]
        if type(list) == "table" then
            for i = 1, #list do
                local card = list[i]
                if type(card) == "table" and type(card.name) == "string" and string.lower(card.name) == target then
                    out[#out + 1] = { card = card, zone = z, index = i }
                end
            end
        end
    end
    return out
end

--[[
    Mélange les cartes dans le tableau donné.
    @param t Le tableau à mélanger.
]]
--[[
Fonction : shuffle
Rôle : Fonction « Shuffle » liée à la logique du jeu.
Paramètres :
  - t : paramètre détecté automatiquement.
Retour : valeur calculée.
]]
local function shuffle(t)
    if type(t) ~= "table" then return end
    for i = #t, 2, -1 do
        local j = love.math.random(i)
        t[i], t[j] = t[j], t[i]
    end
end
--[[
-- charge un set de définitions de cartes dans le deck du tag (Hero/Enemy)
    @param cardsResources La table contenant les définitions de cartes.
    @param actorTag Le tag de l'acteur (Hero/Enemy).
]]
--[[
Fonction : cards.loadCards
Rôle : Fonction « Load cards » liée à la logique du jeu.
Paramètres :
  - cardsResources : paramètre détecté automatiquement.
  - actorTag : paramètre détecté automatiquement.
Retour : aucune valeur (nil).
]]
function cards.loadCards(cardsResources, actorTag)
    actorTag = actorTag or 'Hero'
    assert(type(cardsResources) == "table", "cards.loadCards: cardsResources doit être une table")

    -- on récupérera le deck à partir du 1er retour, puis on le réutilise
    local deckTarget = nil

    for _, def in ipairs(cardsResources) do
        local deckReturn = generateCard.newCard(
            def.name,
            def.ImgIlustration,
            def.Description,
            def.PowerBlow,
            def.Effect,
            1,
            actorTag
        )
        deckTarget = deckTarget or deckReturn
    end

    -- Shuffle UNE seule fois, quand tout est chargé
    shuffle(deckTarget)

    -- utile si tu veux chaîner (pioche, etc.)
    return deckTarget
end

return cards;
